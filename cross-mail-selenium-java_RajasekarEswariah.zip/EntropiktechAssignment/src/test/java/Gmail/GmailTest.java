package Gmail;
import java.util.logging.Logger;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import GmailPages.InboxPage;
import GmailPages.LoginPage;
import utility.BaseClass;

public class GmailTest extends BaseClass{
	
	Logger logger = Logger.getLogger(GmailTest.class.getName());
	LoginPage loginPage = new LoginPage();
	InboxPage inbox = new InboxPage();
	
	
	@Test
//	//** This Test Composed of
//	Login to Gmail - 
//	Compose an email with unique subject and body - 
//	Label email as "Social" - 
//	Send the email to the same account which was used to login (from and to addresses would be the same) - 
//	Wait for the email to arrive in the Inbox - Mark email as starred - 
//	Open the received email - 
//	Verify email came under proper Label i.e. "Social" - 
//	Verify the subject and body of the received email **//
	
	public void ComposeMailAndSend() throws InterruptedException {
		
		loginPage.login();
		String Subject = inbox.ComposeMail();
		int SentEmailNo = inbox.GetSocialEmail(Subject);
		inbox.MarkEmailAsStarredandOpenIt(SentEmailNo);
		String MailSubject = inbox.GetSubjectFromMail();
		String MailBody = inbox.GetBodyFromMail();
		if (Subject.equals(MailSubject)& MailBody.equals("Assignment given by EntropikTeck")){
			
			System.out.println("Gmail test is successfull");
		}
	}
	
	

}

