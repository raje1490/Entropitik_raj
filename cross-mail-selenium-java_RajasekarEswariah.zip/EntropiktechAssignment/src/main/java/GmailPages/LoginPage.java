package GmailPages;

import java.io.FileNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import utility.BaseClass;
import utility.PropLoad;

public class LoginPage extends BaseClass {
	
	private String EmailTextBox= "//input[@type='email']";
	private String EmailNextButton= "//div[@id='identifierNext']/div/button";
	private String PasswordTextBox= "//input[@type='password']";
	private String PasswordNextButton= "//div[@id='passwordNext']/div/button";
	
public void login() {
	
	try {
	driver.get(PropLoad.getProperties("Url"));
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(EmailTextBox))).sendKeys(PropLoad.getProperties("username"));
    driver.findElement(By.xpath(EmailNextButton)).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PasswordTextBox))).sendKeys(PropLoad.getProperties("password"));
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PasswordNextButton))).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='T-I T-I-KE L3']")));
    if (driver.getCurrentUrl().contains("/#inbox")) {
		Assert.assertTrue(true);

    	System.out.println("Gmail logged in susscessfully");
    }}
    catch (Exception e) {
		e.printStackTrace();
	}
}



}
