package GmailPages;

import java.nio.charset.Charset;
import java.util.Random;
import org.apache.commons.lang3.RandomStringUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utility.BaseClass;
import utility.PropLoad;

public class InboxPage extends BaseClass {

	private String ComposeButton= "//div[@class='T-I T-I-KE L3']";
	private String To= "//div[@class='wO nr l1']/textarea";
	private String Subject = "//input[@name='subjectbox']";
	private String mailContent = "//div[@class='Am Al editable LW-avf tS-tW']";
	private String SendEmail = "//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']";
	private String SocialTab = "//div[@aria-label='Social']/div[@class='aKw']";
	private String EmailTextBox= "//input[@type='email']";
	private String EmailNextButton= "//div[@id='identifierNext']/div/button";
	private String PasswordTextBox= "//input[@type='password']";
	private String PasswordNextButton= "//div[@id='passwordNext']/div/button";
	
	
public void LabelEmail() throws InterruptedException {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-label='More options']/div[@class='J-J5-Ji J-JN-M-I-JG']"))).click();
//	driver.findElement(By.xpath("//div[@aria-label='More options']/div[@class='J-J5-Ji J-JN-M-I-JG']")).click();
	Actions actions = new Actions(driver);
	WebElement menuOption = driver.findElement(By.xpath("//div[@role='menuitem']/div[contains(text(),'Label')]"));
	actions.moveToElement(menuOption).perform();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Social']/div/div"))).click();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@role='menuitem']/div[contains(text(),'Apply')]"))).click();

}


public String ComposeMail() throws InterruptedException {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ComposeButton))).click();

	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(To))).click();

	driver.findElement(By.xpath(To)).sendKeys(PropLoad.getProperties("username"));
	driver.findElement(By.xpath(To)).sendKeys(Keys.TAB);
	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Subject))).click();

	//Generate Random String for Java
	String generatedString1=RandomStringUtils.randomAlphabetic(8);

 
    System.out.println(generatedString1);
	driver.findElement(By.xpath(Subject)).sendKeys(generatedString1);
	
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(mailContent))).click();
	driver.findElement(By.xpath(mailContent)).sendKeys(PropLoad.getProperties("body"));
	LabelEmail();

	driver.findElement(By.xpath("//div[text()='Send']")).click();
	return generatedString1;
}	

public int GetSocialEmail(String SubjectText) {
	int SentMailNo= 0;
	try {
		WebDriverWait wait = new WebDriverWait(driver, 30);
	    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SocialTab))).click();
	    Thread.sleep(3000);
	    for(int i=1; i<=5;i++) {
	   
	    String Subject = driver.findElement(By.xpath("//div[@id=':20'and @role='tabpanel']/div[3]/div/table/tbody/tr["+i+"]/td[@class='xY a4W']/div/div/div")).getText();
	    
	    if (Subject.equals(SubjectText)) {
	    	System.out.println("Mail recieved successfully under Social Label Tab");
	    	SentMailNo=i;
	    	break;
	    	}
	    	
	    }} catch (Exception e) {
			e.printStackTrace();
		}
	
	return SentMailNo;
}

public void MarkEmailAsStarredandOpenIt(int MailNo) throws InterruptedException {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=':20'and @role='tabpanel']/div[3]/div/table/tbody/tr["+MailNo+"]/td[@class='apU xY']/span"))).click();
	driver.findElement(By.xpath("//div[@id=':20'and @role='tabpanel']/div[3]/div/table/tbody/tr["+MailNo+"]/td[@role='gridcell']/div[2]")).click();
}


public String GetSubjectFromMail() {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='aeF']/div/div[@class='nH']/div/table[@role='presentation']/tr/td/div/div/div[@class='nH']/div/h2")));
	String Subject = "";
	Subject = driver.findElement(By.xpath("//*[@class='aeF']/div/div[@class='nH']/div/table[@role='presentation']/tr/td/div/div/div[@class='nH']/div/h2")).getText();
	System.out.println(""+Subject);
	return Subject;
}
public String GetBodyFromMail() {
	String Body = "";
	Body = driver.findElement(By.xpath("//*[@class='a3s aXjCH ']/div")).getText();
	return Body;
}

}
