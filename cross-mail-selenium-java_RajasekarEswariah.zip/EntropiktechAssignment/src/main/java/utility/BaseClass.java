package utility;
import org.testng.Assert;
import java.io.FileNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import utility.PropLoad;

public class BaseClass {
	
	public static WebDriver driver;
	
@BeforeClass	
	public void setup() {
			
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/drivers/chromedriver.exe");  
		      
		       // Instantiate a ChromeDriver class.       
		    driver=new ChromeDriver(); 
//		    driver=new FirefoxDriver(); 

		    driver.manage().window().maximize();
		}
@AfterClass
public void teardown() {
	
	driver.quit();
}

}
