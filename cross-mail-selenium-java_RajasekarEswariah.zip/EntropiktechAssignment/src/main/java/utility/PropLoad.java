package utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class PropLoad {
	 
	 
	public static String getProperties(String PropertyName) {
		String PropertyText= "";
		File file = new File(System.getProperty("user.dir")+"/TestData/TestData.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();}
		if (PropertyName.equals("Url")) {
			PropertyText=prop.getProperty("Url");
		}
		else if (PropertyName.equals("username")) {
			PropertyText=prop.getProperty("username");

		}
		else if (PropertyName.equals("password")) {
			PropertyText=prop.getProperty("password");

		}
		else if (PropertyName.equals("body")) {
			PropertyText=prop.getProperty("body");

		}
		
		return PropertyText;
		}		
}